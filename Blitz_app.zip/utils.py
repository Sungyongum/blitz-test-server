import ccxt
import math
from Blitz_app.models import Proxy
from Blitz_app import db
from Blitz_app.models.proxy_status_log import ProxyStatusLog
from Blitz_app.models.user import User

def normalize_symbol(symbol, markets):
    # 완전일치 먼저 확인
    if symbol in markets:
        typ = str(markets[symbol].get('type', '')).lower()
        if 'swap' in typ or 'perpetual' in typ:
            return symbol
    if (symbol + ':USDT') in markets:
        typ = str(markets[symbol + ':USDT'].get('type', '')).lower()
        if 'swap' in typ or 'perpetual' in typ:
            return symbol + ':USDT'
    raise Exception(f"{symbol}에 맞는 Bybit 무기한 선물(Perpetual) 마켓이 없습니다.")

def cancel_tp_sl_orders(ex, symbol, position_idx):
    try:
        orders = ex.fetch_open_orders(symbol, params={'category': 'linear', 'positionIdx': position_idx})
        for o in orders:
            if o.get('reduceOnly'):
                ex.cancel_order(o['id'], symbol, params={'positionIdx': position_idx})
    except Exception as e:
        print("TP/SL 취소 오류:", e)

def cancel_entry_orders(ex, symbol, ccxt_side, position_idx):
    try:
        orders = ex.fetch_open_orders(symbol, params={'category': 'linear', 'positionIdx': position_idx})
        for o in orders:
            if not o.get('reduceOnly'):
                ex.cancel_order(o['id'], symbol, params={'positionIdx': position_idx})
    except Exception as e:
        print("엔트리 주문 취소 오류:", e)

def place_manual_tp_order(exchange, symbol, side, entry_price, tp, amount, position_idx=None):
    try:
        market = exchange.market(symbol)
        tick_size = market.get('precision', {}).get('price', 0.00001)
        digits = abs(int(round(math.log10(tick_size))))
        tp_side = 'sell' if side == 'buy' else 'buy'
        raw_tp_price = entry_price * (1 + tp) if side == 'buy' else entry_price * (1 - tp)
        tp_price = round(raw_tp_price, digits)

        if abs(tp_price - entry_price) < tick_size * 2:
            tp_price = round(entry_price + (tick_size * 2 if side == 'buy' else -tick_size * 2), digits)

        print(f"[TP] 진입가:{entry_price}, TP가:{tp_price}, tick:{tick_size}, side:{side}")

        if (side == "buy" and tp_price <= entry_price) or (side == "sell" and tp_price >= entry_price):
            print("[TP] 진입가와 TP 주문가가 너무 가까워서 TP 주문 생략!")
            return None

        params = {'reduceOnly': True, 'text': 'BOT_ORDER', 'marginMode': 'cross'}
        if position_idx is not None:
            params['positionIdx'] = position_idx

        result = exchange.create_order(
            symbol, 'limit', tp_side, amount, tp_price, params
        )
        print(f"[TP] 리밋 TP 주문: {tp_side} {amount}@{tp_price} (result={result})")
        return result

    except Exception as e:
        print(f"익절 주문 실패: {e}")
        raise

def place_manual_sl_order(exchange, symbol, side, entry_price, sl, amount, position_idx=None):
    try:
        market = exchange.market(symbol)
        tick_size = market.get('precision', {}).get('price', 0.00001)
        digits = abs(int(round(math.log10(tick_size))))
        sl_side = 'sell' if side == 'buy' else 'buy'
        raw_sl_price = entry_price * (1 - sl) if side == 'buy' else entry_price * (1 + sl)
        sl_price = round(raw_sl_price, digits)

        if abs(sl_price - entry_price) < tick_size * 2:
            sl_price = round(entry_price - (tick_size * 2) if side == 'buy' else entry_price + (tick_size * 2), digits)

        print(f"[SL] 진입가:{entry_price}, SL가:{sl_price}, tick:{tick_size}, side:{side}")

        if (side == "buy" and sl_price >= entry_price) or (side == "sell" and sl_price <= entry_price):
            print("[SL] 진입가와 SL 주문가가 너무 가까워서 SL 주문 생략!")
            return None

        params = {
            'reduceOnly': True,
            'stopPrice': sl_price,
            'text': 'BOT_ORDER',
            'marginMode': 'cross'
        }
        if position_idx is not None:
            params['positionIdx'] = position_idx

        result = exchange.create_order(
            symbol, 'stop', sl_side, amount, sl_price, params
        )
        print(f"[SL] 스탑 SL 주문: {sl_side} {amount}@{sl_price} (result={result})")
        return result

    except Exception as e:
        print(f"손절 주문 실패: {e}")
        raise

def get_position(ex, symbol, side, position_idx=None):
    try:
        params = {'category': 'linear'}
        if position_idx is not None:
            params['positionIdx'] = position_idx
        positions = ex.fetch_positions([symbol], params=params)
        for p in positions:
            pos_side = p.get('side', '')
            contracts = float(p.get('contracts', 0))
            if pos_side.lower() == side.lower() and contracts > 0:
                return p
    except Exception as e:
        print("포지션 조회 오류:", e)
    return None

def fetch_balance(api_key, api_secret, user_id=None):
    try:
        proxies = get_user_proxy_dict(user_id) if user_id else None
        ex = ccxt.bybit({
            'apiKey': api_key,
            'secret': api_secret,
            'enableRateLimit': True,
            'options': {'defaultType': 'contract', 'category': 'linear'},
            'proxies': proxies
        })
        bal = ex.fetch_balance(params={'type': 'unified'})
        free_usdt = bal.get('free', {}).get('USDT', 0)
        return free_usdt
    except Exception as e:
        print("잔고 조회 실패:", e)
        return 0

def get_user_proxy_dict(user_id):
    user = User.query.get(user_id)
    if user and user.email == 'admin@admin.com':
        print(f"[프록시 미사용] Admin 계정({user.email})은 프록시를 사용하지 않습니다.")
        return None
    
    proxy = Proxy.query.filter_by(assigned_user_id=user_id).first()
    if proxy:
        proxy_url = f"socks5h://{proxy.username}:{proxy.password}@{proxy.ip}:{proxy.port}"
        return {
            'http': proxy_url,
            'https': proxy_url
        }
    return None

def assign_proxy_to_user(user_id):
    from Blitz_app.models import User, Proxy
    from Blitz_app import db

    user = User.query.get(user_id)

    # admin 계정은 프록시 배정 제외
    if user and user.email == 'admin@admin.com':
        print(f"[프록시 배정 건너뜀] admin 계정 ({user.email})은 프록시를 배정하지 않습니다.")
        return

    existing = Proxy.query.filter_by(assigned_user_id=user_id).first()
    if existing:
        return

    proxy = Proxy.query.filter_by(assigned_user_id=None).first()
    if proxy:
        proxy.assigned_user_id = user_id
        db.session.commit()
        print(f"[프록시 배정 완료] {user.email}에게 프록시 {proxy.ip}:{proxy.port} 할당됨")


def log_status(user_id, message):
    from datetime import datetime
    log = ProxyStatusLog(user_id=user_id, message=message, timestamp=datetime.utcnow())
    db.session.add(log)
    db.session.commit()
