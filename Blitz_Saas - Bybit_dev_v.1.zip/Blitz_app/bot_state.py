# Blitz_app/bot_state.py

# 전역 봇 상태 저장용
bot_events = {}
force_refresh_flags = {}
single_refresh_flags = {}
