import ccxt
import math
import time
import json
import logging
from threading import Event
from .telegram import send_telegram
from .utils import (
    normalize_symbol, cancel_tp_sl_orders, cancel_entry_orders,
    get_position, place_manual_tp_order, place_manual_sl_order, fetch_balance
)
from .trade_log import record_trade
from .bot_state import bot_events, force_refresh_flags, single_refresh_flags
from Blitz_app.models import Proxy
from Blitz_app import db

def get_user_proxy(user_id):
    proxy = Proxy.query.filter_by(assigned_user_id=user_id).first()
    if proxy:
        proxy_url = f"http://{proxy.username}:{proxy.password}@{proxy.ip}"
        return {
            'http': proxy_url,
            'https': proxy_url
        }
    return None

logger = logging.getLogger(__name__)
status = "대기 중"

def run_bot(config, stop_event: Event, user_id: int):
    max_retries = 3
    retry_count = 0

    while retry_count < max_retries:
        try:
            global status
            if 'repeat' not in config or not config['repeat']:
                config['repeat'] = True
            last_logged_pos_str = ""
            force_refresh_flags[user_id] = False
            single_refresh_flags[user_id] = False

            api_key = config['api_key']
            api_secret = config['api_secret']
            api_pw = config.get('api_password') or config.get('uid') or ''
            side_map = {"long": "buy", "short": "sell"}
            side = config['side']
            ccxt_side = side_map.get(side, side)
            position_idx = 1 if side == 'long' else 2

            exchange = ccxt.bybit({
                'apiKey': api_key,
                'secret': api_secret,
                'enableRateLimit': True,
                'options': {'defaultType': 'contract', 'category': 'linear'},
                'proxies': get_user_proxy(user_id)
            })

            exchange.load_markets()
            futures_markets = {k: v for k, v in exchange.markets.items()
                               if (v.get('contract') or v.get('future'))
                               and v.get('quote') == 'USDT'
                               and ('perpetual' in v.get('type', '').lower() or 'swap' in v.get('type', '').lower())}
            symbol = normalize_symbol(config['symbol'], futures_markets)
            leverage = int(config.get('leverage', 1))
            market = futures_markets[symbol]
            tick_size = market['precision']['price'] if 'precision' in market and 'price' in market['precision'] else 0.00001
            digits = abs(int(round(math.log10(tick_size))))
            is_usdt_linear_perp = (
                market.get('type', '').lower() in ['future', 'swap'] and
                market.get('linear', False) and
                market.get('quote', '').upper() == 'USDT'
            )
            use_position_idx = is_usdt_linear_perp

            if use_position_idx:
                try:
                    exchange.set_leverage(leverage, symbol=symbol, params={'positionIdx': position_idx})
                except Exception as e:
                    logger.warning(f"{symbol} set_leverage 오류(무시): {e}")
            else:
                logger.warning(f"{symbol} 마켓은 USDT-perp 선물이 아닙니다. set_leverage() 건너뜀")
            time.sleep(1)

            grids = config['grids']
            tp = float(str(config.get('take_profit', '0')).replace('%', '') or 0) / 100 / leverage
            sl = float(config['stop_loss'].replace('%', '') or 0)
            rounds = int(config['rounds'])
            last_size = last_entry_price = 0
            entry_orders_sent = False
            last_tp_sl_avg_price = None
            min_qty = market['limits']['amount']['min']
            trade_params = {'positionIdx': position_idx} if use_position_idx else {}
            recent = exchange.fetch_my_trades(symbol=symbol, since=None, limit=1000, params=trade_params)
            known_trade_ids = {tr['id'] for tr in recent}
            cancel_entry_orders(exchange, symbol, ccxt_side, position_idx if use_position_idx else None)
            cancel_tp_sl_orders(exchange, symbol, position_idx if use_position_idx else None)

            while not stop_event.is_set():
                try:
                    # 강제 초기화 처리
                    fr = force_refresh_flags.get(user_id, False)
                    sr = single_refresh_flags.get(user_id, False)
                    if fr or sr:
                        cancel_entry_orders(exchange, symbol, ccxt_side, position_idx if use_position_idx else None)
                        cancel_tp_sl_orders(exchange, symbol, position_idx if use_position_idx else None)
                        logger.info(f"[{user_id}] [{'CONT' if fr else 'SINGLE'}_REFRESH] 강제 주문 초기화")
                        if sr:
                            single_refresh_flags[user_id] = False

                    status = "봇 진행중"
                    pos = get_position(exchange, symbol, side, position_idx if use_position_idx else None)
                    size = float(pos['contracts']) if pos else 0

                    # 포지션 종료 감지
                    if size == 0 and last_size > 0:
                        status = "포지션 종료"
                        cancel_entry_orders(exchange, symbol, ccxt_side, position_idx if use_position_idx else None)
                        cancel_tp_sl_orders(exchange, symbol, position_idx if use_position_idx else None)
                        trades = exchange.fetch_my_trades(symbol=symbol, params=trade_params)
                        last_trade = trades[-1] if trades else None
                        if last_trade:
                            exit_p = last_trade['price']
                            realized_pnl = float(last_trade.get('realizedPnl', last_trade['cost'] - last_trade['amount'] * last_trade['price']))
                        else:
                            exit_p = float(exchange.fetch_ticker(symbol)['last'])
                            realized_pnl = ((exit_p - last_entry_price) if side == 'long' else (last_entry_price - exit_p)) * last_size
                        bal = fetch_balance(api_key, api_secret, api_pw)
                        send_telegram(config['telegram_token'], config['telegram_chat_id'],
                                      f"✅ 포지션 종료 PnL={realized_pnl:.4f} (잔고: {bal:.2f})")
                        record_trade(symbol, side, last_entry_price, exit_p, last_size, pos, api_key, api_secret, user_id, pnl=realized_pnl)
                        entry_orders_sent = False
                        last_size = 0
                        last_tp_sl_avg_price = None
                        if not config['repeat']:
                            status = "반복 정지"
                            break
                        time.sleep(10)
                        continue

                    # 시장가 진입
                    if not pos or float(pos.get('contracts', 0)) == 0:
                        status = "시장가 진입"
                        market_price = exchange.fetch_ticker(symbol)['last']
                        invest_usdt = float(grids[0]['amount'])
                        coin_qty = round((invest_usdt * leverage) / market_price, 3)
                        if coin_qty < min_qty:
                            logger.error(f"❌ 주문실패: 수량 {coin_qty} < 최소수량 {min_qty}")
                            send_telegram(config['telegram_token'], config['telegram_chat_id'],
                                f"❌ 주문수량 {coin_qty}는 최소수량({min_qty})보다 적음. 금액/레버리지 확인 필요!")
                            return

                        order_params = {'text': 'BOT_ORDER', 'reduceOnly': False}
                        if use_position_idx:
                            order_params['positionIdx'] = position_idx
                        order = exchange.create_order(symbol, 'market', ccxt_side, coin_qty, None, order_params)
                        tid = order.get('id')
                        if tid:
                            known_trade_ids.add(tid)

                        time.sleep(2)
                        pos = get_position(exchange, symbol, side, position_idx if use_position_idx else None)
                        filled_amount = float(pos['contracts']) if pos else 0
                        filled_price = float(pos['entryPrice']) if pos else 0
                        send_telegram(config['telegram_token'], config['telegram_chat_id'],
                                      f"🟢 신규 진입 @ {filled_price:.4f} {symbol.split('/')[0]}={filled_amount}")
                        last_entry_price = filled_price
                        last_size = filled_amount

                        if filled_amount >= min_qty:
                            try:
                                place_manual_tp_order(exchange, symbol, ccxt_side, filled_price, tp, filled_amount, position_idx if use_position_idx else None)
                                if sl > 0:
                                    place_manual_sl_order(exchange, symbol, ccxt_side, filled_price, sl, filled_amount, position_idx if use_position_idx else None)
                                last_tp_sl_avg_price = filled_price
                            except Exception as e:
                                logger.error(f"[{user_id}] TP/SL 주문실패: {e}")
                        else:
                            logger.warning(f"[{user_id}] TP/SL 미생성 - filled_amount < min_qty (={filled_amount})")
                        time.sleep(5)
                        continue

                    # 4) 그리드 및 TP/SL (추가매수용 limit)
                    if not entry_orders_sent:
                        entry_price = float(pos['entryPrice'])
                        last_entry_price = entry_price
                        price_basis = entry_price
                        for i in range(1, rounds):
                            if i >= len(grids): break
                            invest_usdt = float(grids[i]['amount'])
                            gap = float(grids[i]['gap']) / 100
                            price_basis = price_basis * (1 - gap) if side == 'long' else price_basis * (1 + gap)
                            price_basis = round(price_basis, digits)
                            grid_qty = round((invest_usdt * leverage) / price_basis, 3)
                            if grid_qty < min_qty:
                                logger.warning(f"skip {i+1}회차: qty {grid_qty} < min_qty {min_qty}")
                                continue
                            try:
                                grid_order_params = {'text': 'BOT_ORDER', 'reduceOnly': False}
                                if use_position_idx:
                                    grid_order_params['positionIdx'] = position_idx
                                print(f"[DEBUG][{i+1}회차] 주문가격: {price_basis}, grid_qty: {grid_qty}")
                                grid_order = exchange.create_order(
                                    symbol, 'limit', ccxt_side, grid_qty, price_basis,
                                    grid_order_params
                                )
                                gid = grid_order.get('id')
                                print(f"[DEBUG][{i+1}회차] grid_order result: {grid_order}")
                                if gid:
                                    known_trade_ids.add(gid)
                            except Exception as e:
                                logger.error(f"[{user_id}] 그리드 limit 주문 실패: {e}")

                        entry_orders_sent = True
                        time.sleep(2)
                        new_pos = get_position(exchange, symbol, side, position_idx if use_position_idx else None)
                        if new_pos:
                            ne = float(new_pos['entryPrice'])
                            sz = float(new_pos['contracts'])
                            print(f"[DEBUG] 추가진입 new_pos contracts={sz}, min_qty={min_qty}")
                            if sz > last_size and sz >= min_qty:
                                cancel_tp_sl_orders(exchange, symbol, position_idx if use_position_idx else None)
                                try:
                                    place_manual_tp_order(exchange, symbol, ccxt_side, ne, tp, sz, position_idx if use_position_idx else None)
                                    if sl > 0:
                                        place_manual_sl_order(exchange, symbol, ccxt_side, ne, sl, sz, position_idx if use_position_idx else None)
                                    send_telegram(
                                        config['telegram_token'], config['telegram_chat_id'],
                                        f"🟢 추가 진입 @ {ne:.4f} contracts={sz}"
                                    )
                                    last_tp_sl_avg_price = ne
                                except Exception as e:
                                    logger.error(f"[{user_id}] 추가 TP/SL 주문실패: {e}")
                            else:
                                print(f"[DEBUG] 추가진입 TP/SL 미생성: sz={sz}, min_qty={min_qty}")
                            try:
                                new_pos_str = json.dumps(new_pos, sort_keys=True)
                                if new_pos_str != last_logged_pos_str:
                                    logger.debug(f"[{user_id}] new_pos 변경: {new_pos_str}")
                                    last_logged_pos_str = new_pos_str
                            except Exception as e:
                                logger.warning(f"[{user_id}] new_pos 로그 실패: {e}")

                    # TP/SL 갱신
                    current_entry = float(pos['entryPrice'])
                    sz = float(pos['contracts'])
                    if sz > 0 and tp > 0 and (last_tp_sl_avg_price is None or abs(current_entry - last_tp_sl_avg_price) > 0.01):
                        cancel_tp_sl_orders(exchange, symbol, position_idx if use_position_idx else None)
                        print(f"[DEBUG] TP/SL 갱신 시도 contracts={sz}, min_qty={min_qty}")
                        if sz >= min_qty:
                            try:
                                place_manual_tp_order(exchange, symbol, ccxt_side, current_entry, tp, sz, position_idx if use_position_idx else None)
                                if sl > 0:
                                    place_manual_sl_order(exchange, symbol, ccxt_side, current_entry, sl, sz, position_idx if use_position_idx else None)
                                last_tp_sl_avg_price = current_entry
                            except Exception as e:
                                logger.error(f"[{user_id}] TP/SL 갱신실패: {e}")
                        else:
                            logger.warning(f"[{user_id}] TP/SL 갱신 미생성 - contracts < min_qty (={sz})")

                        last_size = size
                        time.sleep(10)

                except Exception as e:
                    logger.warning(f"[Bot Loop Error] {e}", exc_info=True)
                    send_telegram(config['telegram_token'], config['telegram_chat_id'],
                                  f"⚠️ 반복 중 오류 발생:\n{e}")
                    time.sleep(5)

        except Exception as e:
            retry_count += 1
            logger.error(f"[Bot Error] user_id={user_id} - {e}", exc_info=True)
            time.sleep(5)

            if retry_count >= max_retries:
                send_telegram(config['telegram_token'], config['telegram_chat_id'],
                              f"❌ 봇이 3회 연속 실패로 중단되었습니다.\n에러: {e}")

            try:
                cancel_entry_orders(exchange, symbol, ccxt_side, position_idx if use_position_idx else None)
                cancel_tp_sl_orders(exchange, symbol, position_idx if use_position_idx else None)
                status = "중지됨"
                send_telegram(config['telegram_token'], config['telegram_chat_id'],
                              f"⛔ 자동매매 종료됨 ({symbol} {side})")
            except Exception as cleanup_error:
                logger.error(f"[Cleanup Error] {cleanup_error}", exc_info=True)

            break
