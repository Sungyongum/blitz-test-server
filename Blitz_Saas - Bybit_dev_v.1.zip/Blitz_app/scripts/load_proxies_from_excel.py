# Blitz_app/scripts/load_proxies_from_excel.py

import pandas as pd
from Blitz_app import create_app
from Blitz_app.extensions import db
from Blitz_app.models.proxy_model import Proxy

# 엑셀 파일 경로
EXCEL_PATH = 'proxy_list.xlsx'  # 루트 경로에 위치한다고 가정

app = create_app()

with app.app_context():
    df = pd.read_excel(EXCEL_PATH)

    for _, row in df.iterrows():
        proxy = Proxy(
            ip=row['ip'],
            port=int(row['port']),
            username=row['username'],
            password=row['password'],
            assigned_user_id=None  # 아직 할당 안 함
        )
        db.session.add(proxy)
    db.session.commit()

    print(f"✅ {len(df)}개 프록시 로딩 완료")
